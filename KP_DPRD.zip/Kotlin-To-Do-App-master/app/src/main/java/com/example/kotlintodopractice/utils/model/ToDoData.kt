package com.example.kotlintodopractice.utils.model

data class ToDoData(var taskId:String, var task:String)
